import sys
from PyQt5.QtWidgets import QApplication, QWidget, QMainWindow, QPushButton, QInputDialog, QTableWidgetItem, \
    QTextBrowser
from ui_main_project import Ui_Form
from PyQt5 import uic
from time import perf_counter
from random import choice
import sqlite3


class MyWidget(QMainWindow, Ui_Form):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        '''Создаем классы по классу для инормации о игре, рекордов и самой игры, которые будут показываться,
         при нажатии соответствующей кнопки'''

        self.info = Info()
        self.pushButton_info.clicked.connect(self.show_info)

        self.records = Records()
        self.pushButton_records.clicked.connect(self.show_records)

        self.sapper = ""
        self.pushButton_sapper.clicked.connect(self.show_sapper)

        # Заведем переменную, в которой будут храниться лучшие рекорды, когда нам нужно будет их выводить
        self.result = ""

        self.best()

        self.pushButton_sapper.setStyleSheet("background-color: rgb(200, 255, 255);")
        self.pushButton_info.setStyleSheet("background-color: rgb(255, 220, 255);")
        self.pushButton_records.setStyleSheet("background-color: rgb(255, 255, 200);")

    def show_info(self):
        self.info.show()

    def show_records(self):
        self.records.show()

    def show_sapper(self):
        # Спрашиваем у игрока желаемый уровень сложности, и если он не нажал "отмена", вызываем класс с игрой

        lvl, ok_btn_pressed = QInputDialog.getItem(self, "Уровень сложности для Сапера",
                                                   "Выберете желаемый уровень сложности",
                                                   ("Легко", "Нормально", "Сложно"), 1, False)

        if ok_btn_pressed:
            self.sapper = Sapper(lvl)
            self.sapper.show()

    def best(self):
        # Выведем в tableWidget в меню игры лучшие рекорды
        con = sqlite3.connect("Records.db")
        cur = con.cursor()

        # Возьмем из базы данных все рекорды и поместим их в список
        self.result = cur.execute("select * from Records").fetchall()

        self.tableWidget.setColumnCount(2)
        self.tableWidget.setHorizontalHeaderLabels(["Имя", "Сложность"])

        # Разделим все рекорды по уровням сложности
        lst_easy = list(filter(lambda x: x[-1] == "Легко", self.result))
        lst_norm = list(filter(lambda x: x[-1] == "Нормально", self.result))
        lst_hard = list(filter(lambda x: x[-1] == "Сложно", self.result))
        lst_best = []

        # Для каждого уровня сложности возьмем лучший рукорд - тот, у которого наименьшее время
        if len(lst_easy) > 0:
            lst_best.append(min(lst_easy, key=lambda x: x[2]))
        if len(lst_norm) > 0:
            lst_best.append(min(lst_norm, key=lambda x: x[2]))
        if len(lst_hard) > 0:
            lst_best.append(min(lst_hard, key=lambda x: x[2]))

        # Поместим в tableWidget данные о лучших рекордах
        for i, row in enumerate([[str(j) for j in [i[1], i[3]]] for i in lst_best]):
            self.tableWidget.setRowCount(self.tableWidget.rowCount() + 1)
            for j, elem in enumerate(row):
                self.tableWidget.setItem(i, j, QTableWidgetItem(elem))


class Info(QWidget):
    def __init__(self):
        super().__init__()

        """В случае вызова этого класса, показываем информацию и пояснения по игре,
         которые уже записанны в отдельном файле"""

        uic.loadUi('info_project.ui', self)


class Records(QMainWindow):
    def __init__(self):
        super().__init__()

        # Загружаем файл, в который поместим информацию о всех рекордах
        uic.loadUi('records_project.ui', self)

        # В случае, если Пользователь хочет стереть все рекорды, перенаправляем его в отдельную функцию
        self.pushButton.clicked.connect(self.clear_records)
        self.pushButton.setStyleSheet("background-color: rgb(255, 255, 200);")

        # Загружаем базу данных и записываем все рекорды в список, передаем необходимые параметры в tableWidget
        con = sqlite3.connect("Records.db")
        cur = con.cursor()

        self.result = cur.execute("select * from Records").fetchall()

        self.tableWidget.setColumnCount(3)
        self.tableWidget.setHorizontalHeaderLabels(["Имя", "Время", "Сложность"])

        """Так как рекорды мы будем записывать по уровням сложности 
        (сначала все, кто играл на Легко, потом на Нормально), а в for, через который мы записываем рекорды в виджет,
        нумерация будет каждый раз вестись с нуля, будет удобнее вести нумерацию строк в tableWidget вручную
        Тогда self.number - номер строки, в которую мы записываем данные"""
        self.number = 0

        # отбираем данные по уровню сложности и записываем их в виджет

        for row in [[str(j) for j in i[1:]] for i in sorted(list(filter(lambda x: x[-1] == "Легко",
                                                                        self.result)), key=lambda x: x[2])]:
            self.tableWidget.setRowCount(self.tableWidget.rowCount() + 1)
            for j, elem in enumerate(row):
                self.tableWidget.setItem(self.number, j, QTableWidgetItem(elem))
            self.number += 1

        for row in [[str(j) for j in i[1:]] for i in sorted(list(filter(lambda x: x[-1] == "Нормально",
                                                                        self.result)), key=lambda x: x[2])]:
            self.tableWidget.setRowCount(self.tableWidget.rowCount() + 1)
            for j, elem in enumerate(row):
                self.tableWidget.setItem(self.number, j, QTableWidgetItem(elem))
            self.number += 1

        for row in [[str(j) for j in i[1:]] for i in sorted(list(filter(lambda x: x[-1] == "Сложно",
                                                                        self.result)), key=lambda x: x[2])]:
            self.tableWidget.setRowCount(self.tableWidget.rowCount() + 1)
            for j, elem in enumerate(row):
                self.tableWidget.setItem(self.number, j, QTableWidgetItem(elem))
            self.number += 1

        con.commit()
        con.close()

    def clear_records(self):
        # Если Пользователь пожелал стереть данные, на всякий случай переспрашиваем его в уверенности это сделать

        i, ok_btn_pressed = QInputDialog.getItem(self, "Стереть все рекорды",
                                                 "Вы уверены, что хотите стереть все рекорды?", ("Да", "Нет"), 0, False)

        if i == "Да" and ok_btn_pressed:
            # Если Пользователь точно хочет все удалить, то удаляем
            con = sqlite3.connect("Records.db")
            cur = con.cursor()

            self.result = cur.execute("DELETE from Records").fetchall()

            con.commit()
            con.close()


class Sapper(QMainWindow):
    def __init__(self, lvl):
        super().__init__()
        uic.loadUi('sapper_lvl_project.ui', self)

        '''Это сторона поля в клетках. Для моей программы она постоянна и равна 12, но если менять размер поля,
                что я хотела бы потом осуществить, то этот параметр пригодится'''
        self.number = 12

        # В зависимости от уровня сложности назначаем количество мин
        if lvl == "Легко":
            self.count_mines = 12
            self.dif = "Легко"
        elif lvl == "Нормально":
            self.count_mines = 20
            self.dif = "Нормально"
        else:
            self.count_mines = 30
            self.dif = "Сложно"

        """При нажатии на любую кнопки, кроме "Изменить", вызываем функцию по запуску игры.
        Если же была нажата кнопка "Изменить", то вызываем функцию по смене активног режима"""

        for button in self.findChildren(QPushButton):
            if button.objectName() != "pushButton_change":
                button.clicked.connect(self.run)
            else:
                self.pushButton_change.clicked.connect(self.change)

        """Создаем два игровых поля, в виде матрицы - списков в списке.
        self.field_pl - поле, которое отображает то, что видит игрок. Если тут открыты какие-то ячейки,
        значит их открыл игрок. pl - player
        self.field_pc - поле, на котором отмечены все объекты - все мины, цифорки и пустые клетки. 
        pc - personal computer, так как это поле, можно сказать, видит лишь компьютер
        self.move - обозначает, первый ли "ход" делает игрок. 
        Если да, то при нажатии на кнопку будут выбираться места мин"""

        self.field_pl = [["0" for _ in range(self.number)] for _ in range(self.number)]
        self.field_pc = [["0" for _ in range(self.number)] for _ in range(self.number)]
        self.move = 1

        # Активный режим - открытие клеток, или же флажки. "Левая" - открытие клеток, "Правая" - флажок
        self.mouse_btn = "left"

        # Вводим пустые пока что переменные
        self.win = "None"
        self.time_start = 0
        self.time_game = 0
        self.text = ""
        self.lst_mine = []

        # Обозначаем класс, который вызовется при проигрыше
        self.loss_notify = LoosNotify()

        # Выводим в счетчик начальное количество мин
        self.lcd_count.display(self.count_mines)

    def run(self):
        if self.move:
            """Засекаем время работы программы - время, которое Пользователь играл,
             которое потом, в случае победы, запишем в рекорды"""
            self.time_start = perf_counter()

            """Получим координаты клетки, которую мы нажали и обозначим ее на поле для компьютера. 
            Все кнопки названы в формате "..." + "_" + "координата расположения по х" + "_" +
            "координата расположения по у", поэтому ее координаты получаем из имени"""
            x_0, y_0 = list(map(int, self.sender().objectName().split("_")[1:]))
            self.field_pl[x_0][y_0] = " "
            self.field_pc[x_0][y_0] = " "

            # Введем списки, в которых будут храниться координаты мин - х и у отдельно
            lst_x = []
            lst_y = []

            # Выберем случайные места для мин, количество мин было определено уровнем сложности
            for _ in range(self.count_mines):
                # Создаем список возможных координат и выбираем из него х
                lst = [i for i in range(self.number)]
                x = choice(lst)

                """Теперь надо проследить, чтобы координаты мин не повторялись и не попадали на начальную клетку.
                Для этого исключаем из списка координат, из которого теперь будем выбирать лишь у, те координаты,
                х которых совпал с только что выбранным"""

                if x in lst_x:
                    if lst_x.count(x) == 1:
                        lst.remove(lst_y[lst_x.index(x)])
                    else:
                        for h in range(len(lst_x)):
                            if x == lst_x[h]:
                                lst.remove(lst_y[h])

                # Так же желательно, чтобы начальная клетка и клетки вокруг тоже не были минами

                if x == x_0 or x == x_0 - 1 or x == x_0 + 1:
                    if y_0 in lst:
                        lst.remove(y_0)
                    if y_0 - 1 in lst:
                        lst.remove(y_0 - 1)
                    if y_0 + 1 in lst:
                        lst.remove(y_0 + 1)

                """Теперь, если у нас еще остались доступные координаты, выбираем у,
                 иначе повторяем все точно так же, но уже от у"""

                if len(lst) != 0:
                    y = choice(lst)

                else:
                    lst = [i for i in range(self.number)]
                    y = choice(lst)

                    if y in lst_y:
                        if lst_y.count(y) == 1:
                            lst.remove(lst_x[lst_y.index(y)])
                        else:
                            for h in range(len(lst_y)):
                                if y == lst_y[h]:
                                    lst.remove(lst_x[h])

                    if y == y_0 or y == y_0 - 1 or y == y_0 + 1:
                        if x_0 in lst:
                            lst.remove(x_0)
                        if x_0 - 1 in lst:
                            lst.remove(x_0 - 1)
                        if x_0 + 1 in lst:
                            lst.remove(x_0 + 1)

                """Когда координаты выбраны, записываем их в список и отмечаем на поле компьютера,
                так же добавляем их в список, где будут храниться все мины - self.lst_mine"""
                lst_x.append(x)
                lst_y.append(y)
                self.field_pc[x][y] = "*"
                self.lst_mine.append([x, y])

                """Вокруг каждой мины прибавим значение клетки на 1 - клетка имеет + 1 соседа-мину, обозначим это
                на поле для компьютера"""

                for i in [-1, 0, 1]:
                    for j in [-1, 0, 1]:
                        if -1 < x + i < self.number and -1 < y + j < self.number and\
                                self.field_pc[x + i][y + j] not in ["*", " "]:
                            self.field_pc[x + i][y + j] = str(int(self.field_pc[x + i][y + j]) + 1)

            """Теперь, дабы после клика на первую кнопку можно было играть дальше, открываем все пустые клетки 
            от начальной. 
            Находим пустую - проверяем ее соседей, когда находим цифры - ее соседей уже не проверяем"""

            empty = [[x_0, y_0]]
            while len(empty) != 0:
                ln = len(empty)
                for f in range(len(empty)):
                    for i in [-1, 0, 1]:
                        for j in [-1, 0, 1]:
                            if -1 < empty[f][0] + i < self.number and -1 < empty[f][1] + j < self.number and\
                                    self.field_pc[empty[f][0] + i][empty[f][1] + j] == "0":

                                # Если в копмьютерном поле стоит "0" - значит эта клетка пустая и мы обозначаем ее " "
                                self.field_pc[empty[f][0] + i][empty[f][1] + j] = " "
                                self.field_pl[empty[f][0] + i][empty[f][1] + j] = " "

                                # На месте клетки делаем серый пустой квадратик
                                self.text = QTextBrowser(self)
                                self.text.resize(31, 31)
                                self.text.move(60 + 30 * (empty[f][1] + j), 90 + 30 * (empty[f][0] + i))
                                self.text.setStyleSheet("background-color: rgb(200, 255, 255);")
                                self.text.show()

                                # Добавляем клетку в список пустых, соседей которых надо проверить
                                empty.append([empty[f][0] + i, empty[f][1] + j])

                            elif -1 < empty[f][0] + i < self.number and -1 < empty[f][1] + j < self.number and\
                                    self.field_pc[empty[f][0] + i][empty[f][1] + j] not in "* ":
                                self.field_pl[empty[f][0] + i][empty[f][1] + j] =\
                                    self.field_pc[empty[f][0] + i][empty[f][1] + j]

                                # Если на клетке цифра, то вместо кнопки делаем квадратик с цифрой
                                self.text = QTextBrowser(self)
                                self.text.setFontPointSize(12)
                                self.text.setText(str(self.field_pc[empty[f][0] + i][empty[f][1] + j]))
                                self.text.resize(31, 31)
                                self.text.move(60 + 30 * (empty[f][1] + j), 90 + 30 * (empty[f][0] + i))
                                self.text.show()

                # Из списка пустых клеток удаляем проверенные
                del empty[:ln]

            # На месте начальной тоже ставим серый пустой квадратик
            self.text = QTextBrowser(self)
            self.text.resize(31, 31)
            self.text.move(60 + 30 * y_0, 90 + 30 * x_0)
            self.text.setStyleSheet("background-color: rgb(200, 255, 255);")
            self.text.show()

            """Следующий ход уже будет не первым, поэтому обозначим его 0
             При проверке первый ли это ход, программа перейдет к ситуации, когда уже не первый"""
            self.move = 0

        else:
            # Получаем координаты
            x_0, y_0 = list(map(int, self.sender().objectName().split("_")[1:]))

            # Если Игрок еще не победил и не проиграл, значит смотрим, какой режим активен - открытие клетки или флажок
            if self.win == "None":
                if self.mouse_btn == "right":
                    """Если активен флажок, то мы его убираем или ставим в зависимости от того, стоял ли он на нажатой
                    кнопке до этого. 
                    Изменяем количество оставшихся флажков на 1 - в зависимости от того, убрали мы флажок или поставили,
                    убираем клетку из списка клеток с минами, если она выбрана правильно и есть в этом списке, 
                    либо же добавляем обратно, если выбрана была правильно, но ее убрали,
                    отображаем на дисплее новое количество оставшихся флажков"""

                    if self.field_pl[x_0][y_0] == "*":

                        self.field_pl[x_0][y_0] = "0"
                        self.sender().setText(" ")

                        self.count_mines += 1
                        self.lcd_count.display(0 if self.count_mines < 0 else self.count_mines)

                        if self.field_pc[x_0][y_0] == "*" and [x_0, y_0] not in self.lst_mine:
                            self.lst_mine.append([x_0, y_0])

                    else:
                        self.field_pl[x_0][y_0] = "*"
                        self.sender().setText(chr(128681))

                        self.count_mines -= 1
                        self.lcd_count.display(0 if self.count_mines < 0 else self.count_mines)

                        if [x_0, y_0] in self.lst_mine:
                            self.lst_mine.remove([x_0, y_0])

                else:
                    # Если мы хотим открыть клетку, то если это не мина, на поле выводится то, что должно на ней стоять
                    if self.field_pc[x_0][y_0] != "*":
                        self.field_pl[x_0][y_0] = " " if self.field_pc[x_0][y_0] == "0" else self.field_pc[x_0][y_0]

                        self.text = QTextBrowser(self)
                        self.text.setFontPointSize(12)
                        self.text.setText(" " if self.field_pc[x_0][y_0] == "0" else self.field_pc[x_0][y_0])
                        self.text.resize(31, 31)
                        self.text.move(60 + 30 * y_0, 90 + 30 * x_0)
                        self.text.show()

                        if self.field_pc[x_0][y_0] == "0":
                            self.text.setStyleSheet("background-color: rgb(200, 255, 255);")

                    elif self.field_pl[x_0][y_0] != "*":
                        # Если это была мина, то выводится сообщение о проигрыше и показываются оставшие нетронутые мины

                        self.win = "False"

                        self.text = QPushButton(self)
                        self.text.setText(chr(128293))
                        self.text.resize(31, 31)
                        self.text.move(60 + 30 * y_0, 90 + 30 * x_0)
                        self.lst_mine.remove([x_0, y_0])
                        self.text.show()

                        self.show_loss_notify()

                        for i in self.lst_mine:
                            self.text = QPushButton(self)
                            self.text.setText(chr(128163))
                            self.text.resize(31, 31)
                            self.text.move(60 + 30 * i[1], 90 + 30 * i[0])
                            self.text.show()

                if self.win != "False" and "0" not in [i for j in self.field_pl for i in j]:
                    """Если на поле не остается пустых кнопок, то выводится сообщение о победе и просьба ввести ник,
                    для записи времени в таблицу рекордов"""

                    self.win = "True"
                    self.time_game = round(perf_counter() - self.time_start, 2)

                    name, ok_btn_pressed = QInputDialog.getText(self, "Победа!",
                                                                "Молодцы, вы победили! \nВаше время: {}. \n"
                                                                "Введите ваш ник,"
                                                                " чтобы записать его в таблицу рекордов""".format(
                                                                    str(self.time_game)))

                    con = sqlite3.connect("Records.db")
                    cur = con.cursor()

                    if ok_btn_pressed and len(name) != 0:
                        result = cur.execute("INSERT INTO Records(Nickname, Points, Difficulty) VALUES('{}',"
                                             " {}, '{}')".format(str(name), str(self.time_game), self.dif)).fetchall()
                    else:
                        result = cur.execute("INSERT INTO Records(Nickname, Points, Difficulty) VALUES('{}',"
                                             " {}, '{}')".format("Noname", str(self.time_game), self.dif)).fetchall()

                    for elem in result:
                        print(elem)

                    con.commit()
                    con.close()

    def change(self):
        """Если мы нажимаем на кнопку смены режимов, то, соответственно, меняем их на противоположный,
        меняем при этом и картинку на кнопочке"""
        if self.mouse_btn == "left":
            self.mouse_btn = "right"
            self.sender().setText(chr(128163))
        else:
            self.mouse_btn = "left"
            self.sender().setText(chr(128269))

    def show_loss_notify(self):
        self.loss_notify.show()


class LoosNotify(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('loss_notify.ui', self)
        # Выводим сообщение о проигрыше


app = QApplication(sys.argv)
ex = MyWidget()
ex.show()
sys.exit(app.exec_())
