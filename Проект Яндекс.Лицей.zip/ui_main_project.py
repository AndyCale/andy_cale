# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'main_project1.ui'
#
# Created by: PyQt5 UI code generator 5.13.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(481, 380)
        self.pushButton_sapper = QtWidgets.QPushButton(Form)
        self.pushButton_sapper.setGeometry(QtCore.QRect(20, 140, 161, 41))
        self.pushButton_sapper.setObjectName("pushButton_sapper")
        self.label = QtWidgets.QLabel(Form)
        self.label.setGeometry(QtCore.QRect(170, 10, 131, 51))
        self.label.setStyleSheet("font: italic 8pt \"Monotype Corsiva\";")
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(Form)
        self.label_2.setGeometry(QtCore.QRect(280, 100, 161, 31))
        self.label_2.setObjectName("label_2")
        self.pushButton_records = QtWidgets.QPushButton(Form)
        self.pushButton_records.setGeometry(QtCore.QRect(20, 200, 161, 41))
        self.pushButton_records.setObjectName("pushButton_records")
        self.pushButton_info = QtWidgets.QPushButton(Form)
        self.pushButton_info.setGeometry(QtCore.QRect(20, 260, 161, 41))
        self.pushButton_info.setObjectName("pushButton_info")
        self.tableWidget = QtWidgets.QTableWidget(Form)
        self.tableWidget.setGeometry(QtCore.QRect(240, 150, 221, 121))
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(0)
        self.tableWidget.setRowCount(0)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.pushButton_sapper.setText(_translate("Form", "Играть"))
        self.label.setText(_translate("Form", "<html><head/><body><p><span style=\" font-size:36pt; text-decoration: underline;\">Сапёр</span></p></body></html>"))
        self.label_2.setText(_translate("Form", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Лучшие в сапере:</span></p></body></html>"))
        self.pushButton_records.setText(_translate("Form", "Рекорды"))
        self.pushButton_info.setText(_translate("Form", "Об игре"))
